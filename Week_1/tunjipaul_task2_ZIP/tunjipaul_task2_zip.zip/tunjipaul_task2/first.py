#collecting user details using f-string 

#create variables using the input function

first_name = input("What is your firstname: ")
age = input("How old are you: " )
#put the final code in a variable
details = f"Welcome {first_name}, you are {age} years old"
print(details)
