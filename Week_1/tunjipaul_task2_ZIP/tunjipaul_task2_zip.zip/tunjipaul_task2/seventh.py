#mixing data types
#create variables for the various required data types.
age = int(input("how old are you? "))
height_in_meters = float(input("how tall are you? "))
full_name = input("what is your full name? ")
#create the response
sentence = input(f"the boy aged {age}, is {height_in_meters} tall and his name is {full_name}.")
print(sentence)