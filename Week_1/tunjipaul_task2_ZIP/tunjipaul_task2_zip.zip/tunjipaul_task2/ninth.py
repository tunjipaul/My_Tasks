#nigeria festival info

festival_name = input("what is the festival name? ")
location = input("where is the location? ")
month = input("held in month ")

response = print(f" the '{festival_name}\' festival is held annually at {location} every {month}. ")

print(response)