#SCHOOL REGISTRATION FORM

#variables for various questions
fullName = input("What is your full name? ")

level = (input("what's your class? "))

state_of_origin = input("what state do you hail from? ")

#final output
output = "Student " + fullName + " is in " + level + " and hails from " + state_of_origin

print(output)