#pricedisplaywithtypecasting
#price stored in variable
price_str = input("hello, what is the price of garri per paint: ")
#string converted to float
price_float = float(price_str)
print(price_float)
#output the response
response = f"the price of garri per paint is N{price_float}K"

print(response)



