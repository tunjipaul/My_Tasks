#using escape sequence to print name of nigerian dish and its state.

dish_name = input("what is your most consumed dish? ")

popular_state = input("what state is it most eaten ? ")

answer = (f"dish:{dish_name}\npopular state is:\t{popular_state}")

print(answer)